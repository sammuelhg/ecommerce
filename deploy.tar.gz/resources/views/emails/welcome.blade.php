@extends('emails.layout')

@section('content')
    <!-- Título -->
    <h1 style="margin: 0; color: #000000; font-size: 24px; font-weight: 800; text-transform: uppercase; letter-spacing: -0.5px; line-height: 1.2;">
        Bem-vindo(a)!
    </h1>
    <p style="margin: 5px 0 20px 0; color: #555555; font-size: 14px; font-weight: 500; text-transform: uppercase; letter-spacing: 1px;">
        {{ $user->name }}
    </p>

    <div style="border-top: 1px solid #e0e0e0; margin-bottom: 20px; width: 100%;"></div>

    <p style="color: #333; font-size: 15px; line-height: 1.6;">
        Sua conta foi criada com sucesso! Aproveite nossas ofertas exclusivas.
    </p>

    <!-- Credenciais -->
    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 3px solid #000;">
        <p style="margin: 5px 0; font-size: 13px; color: #555;"><strong>EMAIL</strong></p>
        <p style="margin: 0 0 10px 0; font-size: 15px; font-weight: 600;">{{ $user->email }}</p>
        
        @if($password)
        <p style="margin: 5px 0; font-size: 13px; color: #555;"><strong>SENHA</strong></p>
        <p style="margin: 0; font-size: 15px; font-weight: 600;">{{ $password }}</p>
        @endif
    </div>

    <div style="text-align: center; margin: 25px 0;">
        <a href="{{ $loginUrl }}" class="btn-primary">Acessar Loja</a>
    </div>

    @if(isset($products) && count($products) > 0)
        <div style="border-top: 1px solid #e0e0e0; margin: 30px 0 20px 0; width: 100%;"></div>
        
        <p style="color: #000; font-weight: 800; font-size: 14px; text-transform: uppercase; margin-bottom: 15px;">
            Destaques para você
        </p>

        <table border="0" cellpadding="0" cellspacing="0" width="100%">
            @foreach($products as $product)
            <tr>
                <td width="60" valign="top" style="padding-bottom: 15px;">
                    @if($product->image)
                        <img src="{{ \Illuminate\Support\Facades\Storage::url($product->image) }}" width="50" height="50" style="border-radius: 6px; object-fit: cover; border: 1px solid #eee;">
                    @else
                        <div style="width: 50px; height: 50px; background-color: #eee; border-radius: 6px;"></div>
                    @endif
                </td>
                <td valign="top" style="padding-bottom: 15px; padding-left: 10px;">
                    <a href="{{ route('shop.product', $product->slug) }}" style="text-decoration: none; color: #000; font-weight: 600; font-size: 14px; display: block;">
                        {{ $product->name }}
                    </a>
                    <span style="color: #555; font-size: 13px;">R$ {{ number_format($product->price, 2, ',', '.') }}</span>
                </td>
            </tr>
            @endforeach
        </table>
    @endif

@endsection
