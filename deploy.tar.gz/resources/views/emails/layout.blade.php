<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{{ $subject ?? 'LosFit' }}</title>
<style type="text/css">
  /* Reset básico */
  body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
  table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
  img { -ms-interpolation-mode: bicubic; border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
  table { border-collapse: collapse !important; }
  body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }
  body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #eef1f5; }
  
  /* Botões */
  .btn-primary {
      background-color: #000000;
      color: #ffffff !important;
      padding: 12px 24px;
      border-radius: 6px;
      text-decoration: none;
      display: inline-block;
      font-weight: bold;
      font-size: 14px;
      text-transform: uppercase;
  }
  .btn-primary:hover { background-color: #333333; }
</style>
</head>
<body style="margin: 0; padding: 0; background-color: #eef1f5;">

  <!-- Wrapper Principal -->
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #eef1f5; padding: 20px 0;">
    <tr>
      <td align="center" valign="top">
        
        <!-- Cartão Central -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" style="background-color: #ffffff; border-radius: 16px; border-top: 5px solid #000000; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); max-width: 600px; width: 100%;">
          
          <!-- Layout em Tabela: Coluna Imagem (Esquerda) e Coluna Texto (Direita) -->
          <tr>
            <!-- Coluna da Logo -->
            <td width="200" valign="top" align="center" style="background-color: #f9f9f9; padding: 30px 20px; border-right: 1px solid #eeeeee;">
              <a href="https://losfit.com.br" target="_blank" style="text-decoration: none;">
                <img src="https://losfit.com.br/logo-email.png" alt="LosFit Logo" width="120" style="display: block; width: 120px; max-width: 100%; border: 0;" border="0">
              </a>
              
              <!-- Redes Sociais na Lateral (Opcional, movido do texto principal para cá para limpar o layout) -->
              <div style="margin-top: 30px; text-align: center;">
                  <a href="https://www.instagram.com/losfit1000" target="_blank" style="text-decoration: none; display: inline-block;">
                      <img src="https://cdn-icons-png.flaticon.com/512/87/87390.png" width="24" height="24" alt="IG" style="opacity: 0.7;">
                  </a>
              </div>
            </td>

            <!-- Coluna de Conteúdo -->
            <td valign="top" style="padding: 30px; font-family: 'Segoe UI', Arial, sans-serif;">
              
               @yield('content')

            </td>
          </tr>
          
          <!-- Rodapé -->
          <tr>
            <td colspan="2" align="center" style="background-color: #000000; padding: 12px; color: #ffffff; font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; font-weight: 500; letter-spacing: 0.5px;">
              Saúde • Foco • Resultado
            </td>
          </tr>

        </table>
        
        <!-- Copyright -->
        <table border="0" cellpadding="0" cellspacing="0" width="600">
            <tr>
                <td align="center" style="padding-top: 15px; color: #999999; font-family: Arial, sans-serif; font-size: 10px;">
                    © {{ date('Y') }} LosFit. Todos os direitos reservados.
                </td>
            </tr>
        </table>

      </td>
    </tr>
  </table>

</body>
</html>
