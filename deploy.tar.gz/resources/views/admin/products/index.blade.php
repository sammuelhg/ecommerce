@extends('layouts.admin')

@section('title', 'Gerenciar Produtos')

@section('content')
    @livewire('admin.product-index')
@endsection
