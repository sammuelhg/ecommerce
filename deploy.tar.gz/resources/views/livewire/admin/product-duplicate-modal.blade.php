<div>
    @if($showModal)
    <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Duplicar Produto</h5>
                    <button type="button" class="btn-close" wire:click="closeModal"></button>
                </div>
                <div class="modal-body">
                    @if($originalProduct)
                        <div class="alert alert-info mb-3">
                            <strong>Produto Original:</strong> {{ $originalProduct->name }}<br>
                            <small class="text-muted">
                                Atributo: {{ $originalProduct->attribute ?? 'N/A' }} | 
                                Cor: {{ $originalProduct->productColor->name ?? $originalProduct->color ?? 'N/A' }} | 
                                Tamanho: {{ $originalProduct->productSize->name ?? $originalProduct->size ?? 'N/A' }}
                            </small>
                        </div>

                        @if($errorMessage)
                            <div class="alert alert-danger">
                                <i class="bi bi-exclamation-triangle me-2"></i>{{ $errorMessage }}
                            </div>
                        @endif

                        <form wire:submit.prevent="duplicate">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Atributo (opcional)</label>
                                <input type="text" class="form-control bg-white" wire:model="newAttribute" placeholder="Ex: Manga Longa, Estampado...">
                                <small class="form-text text-muted">Campo genérico adicionado ao título do produto</small>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Cor</label>
                                <select class="form-select bg-white" wire:model="newColorId">
                                    <option value="">Selecione uma cor...</option>
                                    @foreach($availableColors as $color)
                                        <option value="{{ $color->id }}">{{ $color->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Tamanho</label>
                                <select class="form-select bg-white" wire:model="newSizeId">
                                    <option value="">Selecione um tamanho...</option>
                                    @foreach($availableSizes as $size)
                                        <option value="{{ $size->id }}">{{ $size->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="alert alert-warning">
                                <i class="bi bi-info-circle me-2"></i>
                                <strong>Atenção:</strong> Você precisa alterar pelo menos <u>um</u> campo para criar um novo produto.
                            </div>
                        </form>
                    @endif
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click="closeModal">Cancelar</button>
                    <button type="button" class="btn btn-primary" wire:click="duplicate">
                        <i class="bi bi-files me-1"></i> Criar Produto
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
