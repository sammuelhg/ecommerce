<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Card Digital - LosFit1000</title>
  
  <style>
    /* 1. CONFIGURAÇÕES GLOBAIS E VARIÁVEIS DE COR */
    :root {
      /* Cor destaque PRETA conforme solicitado */
      --brand-primary: #000000; 
      --brand-hover: #333333;   
      --text-color-dark: #1a1a1a;
      --text-color-light: #555555;
      --background-color: #eef1f5;
      --card-border-radius: 16px;
    }

    /* 2. ESTILO DO CORPO DA PÁGINA */
    body {
      font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      background-color: var(--background-color);
      margin: 0;
      padding: 2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    /* 3. ESTRUTURA PRINCIPAL DO CARD */
    .custom-card {
      background-color: #ffffff;
      max-width: 600px;
      width: 100%;
      border-radius: var(--card-border-radius);
      /* Borda sutil preta ou cinza escura */
      border-top: 5px solid var(--brand-primary);
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      position: relative;
    }

    /* 4. LAYOUT RESPONSIVO */
    .card-main-content {
      display: flex;
      flex-direction: column;
    }

    @media (min-width: 700px) {
      .card-main-content {
        flex-direction: row;
      }
    }

    /* 5. SEÇÃO DA IMAGEM (LOGO) */
    .card-image-section {
      padding: 2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      flex: 1; 
      background-color: #f9f9f9; /* Fundo leve para destacar o logo */
    }

    .card-image-section img {
      max-width: 140px;
      width: 100%;
      height: auto;
      object-fit: contain;
    }
    
    .card-text-section {
      padding: 2rem;
      flex: 1.5;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    /* 6. TIPOGRAFIA */
    .card-title {
      color: var(--brand-primary);
      font-size: 1.8rem;
      font-weight: 800;
      margin: 0;
      text-transform: uppercase;
      letter-spacing: -0.5px;
    }

    .card-subtitle {
      color: var(--text-color-light);
      font-size: 1rem;
      font-weight: 500;
      margin: 0.25rem 0 1.25rem 0;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-size: 0.8rem;
    }

    /* Linha divisória elegante */
    hr {
      border: 0;
      height: 1px;
      background: #e0e0e0;
      margin: 0 0 1.5rem 0;
      width: 100%;
    }
    
    /* 7. LISTA DE CONTATOS */
    .contact-item {
      display: flex;
      align-items: center;
      margin-bottom: 0.85rem;
      transition: transform 0.2s ease;
    }

    .contact-item:hover {
      transform: translateX(5px); /* Efeito sutil de movimento */
    }
    
    .contact-icon-box {
      width: 32px;
      height: 32px;
      background-color: #f0f0f0;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-right: 12px;
      flex-shrink: 0;
    }

    .contact-item svg {
      width: 16px;
      height: 16px;
      fill: var(--brand-primary);
    }

    .contact-link {
      color: var(--text-color-dark);
      text-decoration: none;
      font-weight: 600;
      font-size: 0.95rem;
      transition: color 0.2s ease;
    }

    .contact-link:hover {
      color: var(--brand-primary);
      text-decoration: underline;
    }

    /* 8. RODAPÉ */
    .card-footer {
      background-color: var(--brand-primary);
      color: #ffffff;
      padding: 1rem;
      text-align: center;
      font-size: 0.8rem;
      font-weight: 500;
      letter-spacing: 0.5px;
    }
  </style>
</head>
<body>

<div class="custom-card">
  
  <div class="card-main-content">
    
    <!-- Área do Logo -->
    <div class="card-image-section">
      <img src="https://losfit.com.br/logo-redonda-trans.png" 
           onerror="this.src='https://losfit.com.br/logo-email.png'" 
           alt="Logo LosFit">
    </div>
    
    <!-- Área de Texto e Links -->
    <div class="card-text-section">
      <h2 class="card-title">LosFit 1000</h2>
      <h3 class="card-subtitle">Performance & Lifestyle</h3>
      
      <hr>

      <!-- Instagram -->
      <div class="contact-item">
        <div class="contact-icon-box" style="background-color: black;">
            <svg xmlns="http://www.w3.org/2000/svg" fill="#fff" viewBox="0 0 16 16">
            <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.232-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
            </svg>
        </div>
        <div>
            <div style="font-size: 0.75rem; color: #777;">Siga-nos no Instagram</div>
            <a href="https://www.instagram.com/losfit1000" target="_blank" class="contact-link">@losfit1000</a>
        </div>
      </div>
      
      <!-- Website -->
      <div class="contact-item">
        <div class="contact-icon-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
            <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m7.5-6.923c-.67.204-1.335.82-1.887 1.855A8 8 0 0 0 5.145 4H7.5zM4.09 4a9.3 9.3 0 0 1 .64-1.539 7 7 0 0 1 .597-.933A7.03 7.03 0 0 0 2.255 4zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a7 7 0 0 0-.656 2.5zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5zM8.5 5v2.5h2.99a12.5 12.5 0 0 0-.337-2.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5zM5.145 12q.208.58.468 1.068c.552 1.035 1.218 1.65 1.887 1.855V12zm.182 2.472a7 7 0 0 1-.597-.933A9.3 9.3 0 0 1 4.09 12H2.255a7 7 0 0 0 3.072 2.472M3.82 11a13.7 13.7 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5zm6.853 3.472A7 7 0 0 0 13.745 12H11.91a9.3 9.3 0 0 1-.64 1.539 7 7 0 0 1-.597.933M8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855q.26-.487.468-1.068zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.7 13.7 0 0 1-.312 2.5m2.802-3.5a7 7 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7 7 0 0 0-3.072-2.472c.218.284.418.598.597.933M10.855 4a8 8 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4z"/>
            </svg>
        </div>
        <a href="https://losfit.com.br" target="_blank" class="contact-link">www.losfit.com.br</a>
      </div>
      
    </div>
  </div>

  <div class="card-footer">
    Saúde • Foco • Resultado
  </div>

</div>

</body>
</html>
