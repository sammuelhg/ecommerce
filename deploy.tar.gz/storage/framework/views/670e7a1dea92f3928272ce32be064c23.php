<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($subject ?? 'LosFit'); ?></title>
    <style>
        /* Reset básico */
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
        table { border-collapse: collapse !important; }
        body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }
        
        /* Estilos do Card */
        .wrapper { background-color: #eef1f5; padding: 40px 20px; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        .card { 
            background-color: #ffffff; 
            max-width: 600px; 
            margin: 0 auto; 
            border-radius: 16px; 
            border-top: 5px solid #000000; 
            overflow: hidden; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.1); 
        }
        .card-content { padding: 0; }
        
        /* Botões */
        .btn-primary {
            background-color: #000000;
            color: #ffffff !important;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
            font-size: 16px;
            margin-top: 15px;
        }
        .btn-primary:hover { background-color: #333333; }
        
        /* Links */
        a { color: #000000; text-decoration: none; }
        a:hover { text-decoration: underline; }
        
        /* Responsividade */
        @media screen and (max-width: 600px) {
            .col-img, .col-text { display: block !important; width: 100% !important; padding: 20px !important; text-align: center !important; }
            .col-img { background-color: #f9f9f9; }
            .card-title { font-size: 24px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; background-color: #eef1f5;">

    <table border="0" cellpadding="0" cellspacing="0" width="100%" class="wrapper">
        <tr>
            <td align="center">
                
                <!-- Card Principal -->
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="card" style="max-width: 600px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                    
                    <!-- Topo Colorido (Borda) -->
                    <tr>
                        <td height="5" style="background-color: #000000; font-size: 0; line-height: 0;">&nbsp;</td>
                    </tr>

                    <tr>
                        <td class="card-content">
                            <!-- Layout de 2 Colunas (Simulado com Tabela) -->
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <!-- Coluna Imagem (Logo) -->
                                    <td class="col-img" width="40%" valign="middle" align="center" style="background-color: #f9f9f9; padding: 30px;">
                                        <img src="<?php echo e(asset('logo-email.png')); ?>" alt="LosFit Logo" width="120" style="display: block; max-width: 100%;">
                                    </td>
                                    
                                    <!-- Coluna Texto -->
                                    <td class="col-text" width="60%" valign="middle" style="padding: 30px;">
                                        <h1 style="color: #000000; font-size: 28px; font-weight: 800; margin: 0; text-transform: uppercase; letter-spacing: -0.5px; line-height: 1.2;">LosFit 1000</h1>
                                        <p style="color: #555555; font-size: 12px; font-weight: 500; margin: 5px 0 20px 0; text-transform: uppercase; letter-spacing: 1px;">Performance & Lifestyle</p>
                                        
                                        <div style="border-top: 1px solid #e0e0e0; margin-bottom: 20px;"></div>

                                        <!-- Conteúdo Dinâmico do Email -->
                                        <div style="color: #333333; font-size: 15px; line-height: 1.6;">
                                            <?php echo $__env->yieldContent('content'); ?>
                                        </div>

                                        <div style="border-top: 1px solid #e0e0e0; margin: 25px 0 20px 0;"></div>

                                        <!-- Redes Sociais / Contato -->
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                            <tr>
                                                <td width="40" valign="middle">
                                                    <div style="width: 32px; height: 32px; background-color: #f0f0f0; border-radius: 50%; text-align: center; line-height: 32px;">
                                                        <img src="https://cdn-icons-png.flaticon.com/512/87/87390.png" width="16" height="16" alt="IG" style="vertical-align: middle;">
                                                    </div>
                                                </td>
                                                <td valign="middle">
                                                    <div style="font-size: 10px; color: #777;">Siga-nos no Instagram</div>
                                                    <a href="https://www.instagram.com/losfit1000" style="color: #000000; font-weight: 600; font-size: 14px;">@losfit1000</a>
                                                </td>
                                            </tr>
                                            <tr><td height="15"></td></tr>
                                            <tr>
                                                <td width="40" valign="middle">
                                                    <div style="width: 32px; height: 32px; background-color: #f0f0f0; border-radius: 50%; text-align: center; line-height: 32px;">
                                                        <img src="https://cdn-icons-png.flaticon.com/512/1006/1006771.png" width="16" height="16" alt="Web" style="vertical-align: middle;">
                                                    </div>
                                                </td>
                                                <td valign="middle">
                                                    <a href="<?php echo e(route('shop.index')); ?>" style="color: #000000; font-weight: 600; font-size: 14px;">www.losfit.com.br</a>
                                                </td>
                                            </tr>
                                        </table>

                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- Rodapé -->
                    <tr>
                        <td align="center" style="background-color: #000000; color: #ffffff; padding: 15px; font-size: 12px; font-weight: 500; letter-spacing: 0.5px;">
                            Saúde • Foco • Resultado
                        </td>
                    </tr>
                </table>
                
                <p style="text-align: center; margin-top: 20px; font-size: 11px; color: #999;">
                    &copy; <?php echo e(date('Y')); ?> LosFit. Todos os direitos reservados.
                </p>

            </td>
        </tr>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecommerce\ecommerce-hp\resources\views/emails/layout.blade.php ENDPATH**/ ?>