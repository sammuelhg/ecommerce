<div class="nav-link">
    <i class="bi bi-cart"></i> Cart <span class="badge bg-secondary">0</span>
</div>
<?php /**PATH C:\xampp\htdocs\ecommerce\ecommerce-hp\resources\views/livewire/cart-icon.blade.php ENDPATH**/ ?>