<?php

declare(strict_types=1);

namespace App\Services;

abstract class BaseService implements ServiceInterface
{
    // No futuro, podemos colocar métodos de log ou transação de DB aqui
}
