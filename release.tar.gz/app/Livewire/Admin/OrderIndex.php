<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class OrderIndex extends Component
{
    public function render()
    {
        return view('livewire.admin.order-index');
    }
}
