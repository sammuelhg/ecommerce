import './bootstrap';

// Bootstrap is loaded via CDN to avoid conflicts
// import * as bootstrap from 'bootstrap';
// window.bootstrap = bootstrap;

// Alpine is handled by Livewire v3
