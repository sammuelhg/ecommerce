@extends('emails.layouts.global')

@section('content')
    {!! $campaign->body !!}
@endsection
