<div>
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Lista de Pedidos</h5>
        </div>
        <div class="card-body">
            <div class="text-center text-muted py-5">
                <i class="bi bi-cart-check" style="font-size: 4rem;"></i>
                <h4 class="mt-3">Nenhum pedido encontrado</h4>
                <p>Os pedidos dos clientes aparecerão aqui quando forem realizados.</p>
            </div>
        </div>
    </div>
</div>
