@extends('layouts.admin')

@section('title', 'Links da Bio')

@section('content')
    <livewire:admin.link-item-index />
@endsection
