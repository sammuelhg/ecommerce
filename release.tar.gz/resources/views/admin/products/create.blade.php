@extends('layouts.admin')

@section('title', 'Novo Produto')

@section('content')
    @livewire('admin.product-form')
@endsection
