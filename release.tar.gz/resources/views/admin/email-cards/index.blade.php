@extends('layouts.admin')

@section('title', 'Cards de Email')

@section('content')
    <livewire:admin.email-card-index />
@endsection
